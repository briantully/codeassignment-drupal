<?php
print 'SimpleTest PHP was executed!';
